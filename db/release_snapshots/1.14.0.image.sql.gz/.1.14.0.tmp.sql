--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg110+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_text_rich_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.action_text_rich_texts (
    id bigint NOT NULL,
    name character varying NOT NULL,
    body text,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.action_text_rich_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.action_text_rich_texts_id_seq OWNED BY public.action_text_rich_texts.id;


--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_attachments (
    id bigint NOT NULL,
    name character varying NOT NULL,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    blob_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_attachments_id_seq OWNED BY public.active_storage_attachments.id;


--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_blobs (
    id bigint NOT NULL,
    key character varying NOT NULL,
    filename character varying NOT NULL,
    content_type character varying,
    metadata text,
    service_name character varying NOT NULL,
    byte_size bigint NOT NULL,
    checksum character varying,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_blobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_blobs_id_seq OWNED BY public.active_storage_blobs.id;


--
-- Name: active_storage_variant_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_variant_records (
    id bigint NOT NULL,
    blob_id bigint NOT NULL,
    variation_digest character varying NOT NULL
);


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_variant_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_variant_records_id_seq OWNED BY public.active_storage_variant_records.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.areas (
    id bigint NOT NULL,
    name character varying NOT NULL,
    user_id bigint NOT NULL,
    longitude numeric(10,6) NOT NULL,
    latitude numeric(10,6) NOT NULL,
    radius integer NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: areas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.areas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.areas_id_seq OWNED BY public.areas.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    id bigint NOT NULL,
    name character varying NOT NULL,
    iso_a2 character varying NOT NULL,
    iso_a3 character varying NOT NULL,
    geom public.geometry(MultiPolygon,4326),
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: data_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_migrations (
    version character varying NOT NULL
);


--
-- Name: digests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digests (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    year integer NOT NULL,
    period_type integer DEFAULT 0 NOT NULL,
    distance bigint DEFAULT 0 NOT NULL,
    toponyms jsonb DEFAULT '{}'::jsonb,
    monthly_distances jsonb DEFAULT '{}'::jsonb,
    time_spent_by_location jsonb DEFAULT '{}'::jsonb,
    first_time_visits jsonb DEFAULT '{}'::jsonb,
    year_over_year jsonb DEFAULT '{}'::jsonb,
    all_time_stats jsonb DEFAULT '{}'::jsonb,
    sharing_settings jsonb DEFAULT '{}'::jsonb,
    sharing_uuid uuid,
    sent_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    month integer,
    travel_patterns jsonb DEFAULT '{}'::jsonb
);


--
-- Name: digests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digests_id_seq OWNED BY public.digests.id;


--
-- Name: exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exports (
    id bigint NOT NULL,
    name character varying NOT NULL,
    url character varying,
    status integer DEFAULT 0 NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    file_format integer DEFAULT 0,
    start_at timestamp(6) without time zone,
    end_at timestamp(6) without time zone,
    file_type integer DEFAULT 0 NOT NULL,
    processing_started_at timestamp(6) without time zone,
    error_message text
);


--
-- Name: exports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exports_id_seq OWNED BY public.exports.id;


--
-- Name: families; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.families (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: families_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.families_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: families_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.families_id_seq OWNED BY public.families.id;


--
-- Name: family_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.family_invitations (
    id bigint NOT NULL,
    family_id bigint NOT NULL,
    email character varying NOT NULL,
    token character varying NOT NULL,
    expires_at timestamp(6) without time zone NOT NULL,
    invited_by_id bigint NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: family_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.family_invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: family_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.family_invitations_id_seq OWNED BY public.family_invitations.id;


--
-- Name: family_location_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.family_location_requests (
    id bigint NOT NULL,
    requester_id bigint NOT NULL,
    target_user_id bigint NOT NULL,
    family_id bigint NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    suggested_duration character varying DEFAULT '24h'::character varying NOT NULL,
    expires_at timestamp(6) without time zone NOT NULL,
    responded_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: family_location_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.family_location_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: family_location_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.family_location_requests_id_seq OWNED BY public.family_location_requests.id;


--
-- Name: family_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.family_memberships (
    id bigint NOT NULL,
    family_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: family_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.family_memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: family_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.family_memberships_id_seq OWNED BY public.family_memberships.id;


--
-- Name: flights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flights (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    external_id integer NOT NULL,
    flight_date date,
    date_precision character varying DEFAULT 'day'::character varying NOT NULL,
    departure_time timestamp(6) without time zone,
    arrival_time timestamp(6) without time zone,
    from_code character varying,
    from_name character varying,
    from_lat double precision,
    from_lon double precision,
    to_code character varying,
    to_name character varying,
    to_lat double precision,
    to_lon double precision,
    airline_name character varying,
    airline_iata character varying,
    aircraft_name character varying,
    aircraft_reg character varying,
    flight_number character varying,
    seat character varying,
    seat_class character varying,
    note text,
    distance_km double precision,
    raw jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: flights_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flights_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flights_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flights_id_seq OWNED BY public.flights.id;


--
-- Name: flipper_features; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flipper_features (
    id bigint NOT NULL,
    key character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: flipper_features_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flipper_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flipper_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flipper_features_id_seq OWNED BY public.flipper_features.id;


--
-- Name: flipper_gates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flipper_gates (
    id bigint NOT NULL,
    feature_key character varying NOT NULL,
    key character varying NOT NULL,
    value text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: flipper_gates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flipper_gates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flipper_gates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flipper_gates_id_seq OWNED BY public.flipper_gates.id;


--
-- Name: imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imports (
    id bigint NOT NULL,
    name character varying NOT NULL,
    user_id bigint NOT NULL,
    source integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    raw_points integer DEFAULT 0,
    doubles integer DEFAULT 0,
    processed integer DEFAULT 0,
    raw_data jsonb,
    points_count integer DEFAULT 0,
    status integer DEFAULT 0 NOT NULL,
    processing_started_at timestamp(6) without time zone,
    error_message text,
    demo boolean DEFAULT false NOT NULL,
    additional_data_extraction_status integer DEFAULT 0 NOT NULL,
    additional_data_extraction jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: imports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.imports_id_seq OWNED BY public.imports.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    title character varying,
    body text,
    lonlat public.geography(Point,4326),
    attachable_type character varying,
    attachable_id bigint,
    noted_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    title character varying NOT NULL,
    content text NOT NULL,
    user_id bigint NOT NULL,
    kind integer DEFAULT 0 NOT NULL,
    read_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: pending_imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_imports (
    id bigint NOT NULL,
    claim_ticket uuid DEFAULT gen_random_uuid() NOT NULL,
    original_filename character varying NOT NULL,
    source_hint character varying,
    origin character varying NOT NULL,
    expires_at timestamp(6) without time zone NOT NULL,
    claimed_at timestamp(6) without time zone,
    claimed_by_user_id bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: pending_imports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pending_imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pending_imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pending_imports_id_seq OWNED BY public.pending_imports.id;


--
-- Name: place_visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.place_visits (
    id bigint NOT NULL,
    place_id bigint NOT NULL,
    visit_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: place_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.place_visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: place_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.place_visits_id_seq OWNED BY public.place_visits.id;


--
-- Name: places; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.places (
    id bigint NOT NULL,
    name character varying NOT NULL,
    longitude numeric(10,6) NOT NULL,
    latitude numeric(10,6) NOT NULL,
    city character varying,
    country character varying,
    source integer DEFAULT 0,
    geodata jsonb DEFAULT '{}'::jsonb NOT NULL,
    reverse_geocoded_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    lonlat public.geography(Point,4326),
    user_id bigint NOT NULL,
    note text,
    demo boolean DEFAULT false NOT NULL,
    name_locked_at timestamp(6) without time zone,
    import_id bigint
);


--
-- Name: places_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.places_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: places_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.places_id_seq OWNED BY public.places.id;


--
-- Name: point_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.point_sources (
    id integer NOT NULL,
    digest character varying(32) NOT NULL,
    tracker_id character varying,
    topic character varying,
    ssid character varying,
    bssid character varying,
    connection integer,
    trigger integer,
    battery_status integer,
    inrids text[],
    in_regions text[],
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: point_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.point_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: point_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.point_sources_id_seq OWNED BY public.point_sources.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id bigint NOT NULL,
    battery_status integer,
    ping character varying,
    battery integer,
    tracker_id character varying,
    topic character varying,
    altitude integer,
    velocity character varying,
    trigger integer,
    bssid character varying,
    ssid character varying,
    connection integer,
    vertical_accuracy integer,
    accuracy integer,
    "timestamp" integer,
    mode integer,
    inrids text[] DEFAULT '{}'::text[],
    in_regions text[] DEFAULT '{}'::text[],
    raw_data jsonb DEFAULT '{}'::jsonb,
    import_id bigint,
    city character varying,
    country character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint,
    geodata jsonb DEFAULT '{}'::jsonb NOT NULL,
    visit_id bigint,
    reverse_geocoded_at timestamp(6) without time zone,
    course numeric(8,5),
    course_accuracy numeric(8,5),
    external_track_id character varying,
    lonlat public.geography(Point,4326),
    country_id bigint,
    track_id bigint,
    country_name character varying,
    raw_data_archived boolean DEFAULT false NOT NULL,
    raw_data_archive_id bigint,
    motion_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    altitude_decimal numeric(10,2),
    anomaly boolean,
    source_id integer
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: points_raw_data_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points_raw_data_archives (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    chunk_number integer DEFAULT 1 NOT NULL,
    point_count integer NOT NULL,
    point_ids_checksum character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    archived_at timestamp(6) without time zone NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    verified_at timestamp(6) without time zone
);


--
-- Name: points_raw_data_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_raw_data_archives_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_raw_data_archives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_raw_data_archives_id_seq OWNED BY public.points_raw_data_archives.id;


--
-- Name: posters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posters (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: posters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posters_id_seq OWNED BY public.posters.id;


--
-- Name: route_videos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.route_videos (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    expired_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: route_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.route_videos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: route_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.route_videos_id_seq OWNED BY public.route_videos.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: service_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_settings (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    service integer NOT NULL,
    provider character varying NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    credentials text,
    active boolean DEFAULT false NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: service_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_settings_id_seq OWNED BY public.service_settings.id;


--
-- Name: shared_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id bigint NOT NULL,
    resource_type integer NOT NULL,
    resource_id bigint,
    name character varying(255) NOT NULL,
    magic_phrase character varying(255),
    expires_at timestamp(6) without time zone,
    revoked_at timestamp(6) without time zone,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    last_accessed_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stats (
    id bigint NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    distance bigint NOT NULL,
    toponyms jsonb,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint NOT NULL,
    daily_distance jsonb DEFAULT '{}'::jsonb,
    sharing_settings jsonb DEFAULT '{}'::jsonb,
    sharing_uuid uuid,
    h3_hex_ids jsonb DEFAULT '{}'::jsonb
);


--
-- Name: stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stats_id_seq OWNED BY public.stats.id;


--
-- Name: taggings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggings (
    id bigint NOT NULL,
    taggable_type character varying NOT NULL,
    taggable_id bigint NOT NULL,
    tag_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: taggings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taggings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taggings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taggings_id_seq OWNED BY public.taggings.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name character varying NOT NULL,
    icon character varying,
    color character varying,
    user_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    privacy_radius_meters integer,
    demo boolean DEFAULT false NOT NULL
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: track_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.track_segments (
    id bigint NOT NULL,
    track_id bigint NOT NULL,
    transportation_mode integer DEFAULT 0 NOT NULL,
    start_index integer,
    end_index integer,
    distance integer,
    duration integer,
    avg_speed double precision,
    max_speed double precision,
    avg_acceleration double precision,
    confidence integer DEFAULT 0,
    source character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    corrected_at timestamp(6) without time zone,
    start_at timestamp with time zone,
    end_at timestamp with time zone,
    path public.geometry(LineString,4326),
    confidence_score double precision
);


--
-- Name: track_segments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.track_segments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: track_segments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.track_segments_id_seq OWNED BY public.track_segments.id;


--
-- Name: tracks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracks (
    id bigint NOT NULL,
    start_at timestamp(6) without time zone NOT NULL,
    end_at timestamp(6) without time zone NOT NULL,
    user_id bigint NOT NULL,
    original_path public.geometry(LineString,4326) NOT NULL,
    distance bigint,
    avg_speed double precision,
    duration integer,
    elevation_gain integer,
    elevation_loss integer,
    elevation_max integer,
    elevation_min integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    dominant_mode integer DEFAULT 0,
    tracker_id character varying,
    demo boolean DEFAULT false NOT NULL,
    import_id bigint
);


--
-- Name: tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tracks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tracks_id_seq OWNED BY public.tracks.id;


--
-- Name: trips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trips (
    id bigint NOT NULL,
    name character varying NOT NULL,
    started_at timestamp(6) without time zone NOT NULL,
    ended_at timestamp(6) without time zone NOT NULL,
    distance integer,
    user_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    path public.geometry(LineString,4326),
    visited_countries jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_recalculated_at timestamp(6) without time zone,
    demo boolean DEFAULT false NOT NULL
);


--
-- Name: trips_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trips_id_seq OWNED BY public.trips.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp(6) without time zone,
    remember_created_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    api_key character varying DEFAULT ''::character varying NOT NULL,
    theme character varying DEFAULT 'dark'::character varying NOT NULL,
    settings jsonb DEFAULT '{"fog_of_war_meters": "100", "meters_between_routes": "1000", "minutes_between_routes": "60"}'::jsonb,
    admin boolean DEFAULT false,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp(6) without time zone,
    last_sign_in_at timestamp(6) without time zone,
    current_sign_in_ip character varying,
    last_sign_in_ip character varying,
    status integer DEFAULT 0,
    active_until timestamp(6) without time zone,
    points_count integer DEFAULT 0 NOT NULL,
    provider character varying,
    uid character varying,
    utm_source character varying,
    utm_medium character varying,
    utm_campaign character varying,
    utm_term character varying,
    utm_content character varying,
    deleted_at timestamp(6) without time zone,
    plan integer DEFAULT 1 NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_at timestamp(6) without time zone,
    unlock_token character varying,
    otp_secret character varying,
    consumed_timestep integer,
    otp_required_for_login boolean DEFAULT false NOT NULL,
    otp_backup_codes text[],
    subscription_source integer DEFAULT 0 NOT NULL,
    signup_variant character varying,
    failed_otp_attempts integer DEFAULT 0 NOT NULL,
    otp_locked_at timestamp(6) without time zone,
    visits_redetected_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    first_name character varying,
    last_name character varying,
    changelog_consent integer
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    area_id bigint,
    user_id bigint NOT NULL,
    started_at timestamp(6) without time zone NOT NULL,
    ended_at timestamp(6) without time zone NOT NULL,
    duration integer NOT NULL,
    name character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    place_id bigint,
    demo boolean DEFAULT false NOT NULL,
    confidence smallint,
    confidence_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL,
    import_id bigint,
    deleted_at timestamp(6) without time zone,
    detection_version smallint
);


--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: action_text_rich_texts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.action_text_rich_texts ALTER COLUMN id SET DEFAULT nextval('public.action_text_rich_texts_id_seq'::regclass);


--
-- Name: active_storage_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments ALTER COLUMN id SET DEFAULT nextval('public.active_storage_attachments_id_seq'::regclass);


--
-- Name: active_storage_blobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_blobs ALTER COLUMN id SET DEFAULT nextval('public.active_storage_blobs_id_seq'::regclass);


--
-- Name: active_storage_variant_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records ALTER COLUMN id SET DEFAULT nextval('public.active_storage_variant_records_id_seq'::regclass);


--
-- Name: areas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas ALTER COLUMN id SET DEFAULT nextval('public.areas_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: digests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digests ALTER COLUMN id SET DEFAULT nextval('public.digests_id_seq'::regclass);


--
-- Name: exports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports ALTER COLUMN id SET DEFAULT nextval('public.exports_id_seq'::regclass);


--
-- Name: families id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families ALTER COLUMN id SET DEFAULT nextval('public.families_id_seq'::regclass);


--
-- Name: family_invitations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations ALTER COLUMN id SET DEFAULT nextval('public.family_invitations_id_seq'::regclass);


--
-- Name: family_location_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_location_requests ALTER COLUMN id SET DEFAULT nextval('public.family_location_requests_id_seq'::regclass);


--
-- Name: family_memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships ALTER COLUMN id SET DEFAULT nextval('public.family_memberships_id_seq'::regclass);


--
-- Name: flights id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flights ALTER COLUMN id SET DEFAULT nextval('public.flights_id_seq'::regclass);


--
-- Name: flipper_features id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flipper_features ALTER COLUMN id SET DEFAULT nextval('public.flipper_features_id_seq'::regclass);


--
-- Name: flipper_gates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flipper_gates ALTER COLUMN id SET DEFAULT nextval('public.flipper_gates_id_seq'::regclass);


--
-- Name: imports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports ALTER COLUMN id SET DEFAULT nextval('public.imports_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: pending_imports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_imports ALTER COLUMN id SET DEFAULT nextval('public.pending_imports_id_seq'::regclass);


--
-- Name: place_visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits ALTER COLUMN id SET DEFAULT nextval('public.place_visits_id_seq'::regclass);


--
-- Name: places id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places ALTER COLUMN id SET DEFAULT nextval('public.places_id_seq'::regclass);


--
-- Name: point_sources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.point_sources ALTER COLUMN id SET DEFAULT nextval('public.point_sources_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: points_raw_data_archives id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_raw_data_archives ALTER COLUMN id SET DEFAULT nextval('public.points_raw_data_archives_id_seq'::regclass);


--
-- Name: posters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posters ALTER COLUMN id SET DEFAULT nextval('public.posters_id_seq'::regclass);


--
-- Name: route_videos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route_videos ALTER COLUMN id SET DEFAULT nextval('public.route_videos_id_seq'::regclass);


--
-- Name: service_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_settings ALTER COLUMN id SET DEFAULT nextval('public.service_settings_id_seq'::regclass);


--
-- Name: stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats ALTER COLUMN id SET DEFAULT nextval('public.stats_id_seq'::regclass);


--
-- Name: taggings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggings ALTER COLUMN id SET DEFAULT nextval('public.taggings_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: track_segments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.track_segments ALTER COLUMN id SET DEFAULT nextval('public.track_segments_id_seq'::regclass);


--
-- Name: tracks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracks ALTER COLUMN id SET DEFAULT nextval('public.tracks_id_seq'::regclass);


--
-- Name: trips id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trips ALTER COLUMN id SET DEFAULT nextval('public.trips_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: action_text_rich_texts action_text_rich_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.action_text_rich_texts
    ADD CONSTRAINT action_text_rich_texts_pkey PRIMARY KEY (id);


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: active_storage_variant_records active_storage_variant_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT active_storage_variant_records_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: areas areas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT areas_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: data_migrations data_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_migrations
    ADD CONSTRAINT data_migrations_pkey PRIMARY KEY (version);


--
-- Name: digests digests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digests
    ADD CONSTRAINT digests_pkey PRIMARY KEY (id);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (id);


--
-- Name: families families_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT families_pkey PRIMARY KEY (id);


--
-- Name: family_invitations family_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations
    ADD CONSTRAINT family_invitations_pkey PRIMARY KEY (id);


--
-- Name: family_location_requests family_location_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_location_requests
    ADD CONSTRAINT family_location_requests_pkey PRIMARY KEY (id);


--
-- Name: family_memberships family_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships
    ADD CONSTRAINT family_memberships_pkey PRIMARY KEY (id);


--
-- Name: flights flights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT flights_pkey PRIMARY KEY (id);


--
-- Name: flipper_features flipper_features_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flipper_features
    ADD CONSTRAINT flipper_features_pkey PRIMARY KEY (id);


--
-- Name: flipper_gates flipper_gates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flipper_gates
    ADD CONSTRAINT flipper_gates_pkey PRIMARY KEY (id);


--
-- Name: imports imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT imports_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: pending_imports pending_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_imports
    ADD CONSTRAINT pending_imports_pkey PRIMARY KEY (id);


--
-- Name: place_visits place_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits
    ADD CONSTRAINT place_visits_pkey PRIMARY KEY (id);


--
-- Name: places places_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_pkey PRIMARY KEY (id);


--
-- Name: point_sources point_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.point_sources
    ADD CONSTRAINT point_sources_pkey PRIMARY KEY (id);


--
-- Name: points points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_pkey PRIMARY KEY (id);


--
-- Name: points_raw_data_archives points_raw_data_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_raw_data_archives
    ADD CONSTRAINT points_raw_data_archives_pkey PRIMARY KEY (id);


--
-- Name: posters posters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posters
    ADD CONSTRAINT posters_pkey PRIMARY KEY (id);


--
-- Name: route_videos route_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route_videos
    ADD CONSTRAINT route_videos_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: service_settings service_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_settings
    ADD CONSTRAINT service_settings_pkey PRIMARY KEY (id);


--
-- Name: shared_links shared_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_links
    ADD CONSTRAINT shared_links_pkey PRIMARY KEY (id);


--
-- Name: stats stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT stats_pkey PRIMARY KEY (id);


--
-- Name: taggings taggings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggings
    ADD CONSTRAINT taggings_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: track_segments track_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.track_segments
    ADD CONSTRAINT track_segments_pkey PRIMARY KEY (id);


--
-- Name: tracks tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_pkey PRIMARY KEY (id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: users users_admin_null; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.users
    ADD CONSTRAINT users_admin_null CHECK ((admin IS NOT NULL)) NOT VALID;


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: idx_family_loc_requests_expires_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_family_loc_requests_expires_status ON public.family_location_requests USING btree (expires_at, status);


--
-- Name: idx_family_loc_requests_requester_target_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_family_loc_requests_requester_target_status ON public.family_location_requests USING btree (requester_id, target_user_id, status);


--
-- Name: idx_family_loc_requests_target_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_family_loc_requests_target_status ON public.family_location_requests USING btree (target_user_id, status);


--
-- Name: idx_place_visits_visit_id_place_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_place_visits_visit_id_place_id ON public.place_visits USING btree (visit_id, place_id);


--
-- Name: idx_places_import_id_extracted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_places_import_id_extracted ON public.places USING btree (import_id) WHERE (import_id IS NOT NULL);


--
-- Name: idx_places_user_external_place_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_places_user_external_place_id ON public.places USING btree (user_id, ((geodata ->> 'external_place_id'::text))) WHERE ((geodata ->> 'external_place_id'::text) IS NOT NULL);


--
-- Name: idx_points_track_id_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_points_track_id_timestamp ON public.points USING btree (track_id, "timestamp");


--
-- Name: idx_points_user_id_legacy_tracker; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_points_user_id_legacy_tracker ON public.points USING btree (user_id) WHERE ((tracker_id)::text = ANY ((ARRAY['google-maps-timeline-export'::character varying, 'google-maps-phone-timeline-export'::character varying])::text[]));


--
-- Name: idx_track_segments_track_start_at_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_track_segments_track_start_at_unique ON public.track_segments USING btree (track_id, start_at) WHERE (start_at IS NOT NULL);


--
-- Name: idx_track_segments_track_start_index_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_track_segments_track_start_index_unique ON public.track_segments USING btree (track_id, start_index);


--
-- Name: idx_tracks_import_id_extracted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracks_import_id_extracted ON public.tracks USING btree (import_id) WHERE (import_id IS NOT NULL);


--
-- Name: idx_tracks_user_id_start_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracks_user_id_start_at ON public.tracks USING btree (user_id, start_at);


--
-- Name: idx_tracks_user_tracker_end_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracks_user_tracker_end_at ON public.tracks USING btree (user_id, tracker_id, end_at);


--
-- Name: idx_visits_import_id_extracted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visits_import_id_extracted ON public.visits USING btree (import_id) WHERE (import_id IS NOT NULL);


--
-- Name: idx_visits_user_started_at_place_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_visits_user_started_at_place_unique ON public.visits USING btree (user_id, started_at, place_id);


--
-- Name: index_action_text_rich_texts_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_action_text_rich_texts_uniqueness ON public.action_text_rich_texts USING btree (record_type, record_id, name);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_active_storage_variant_records_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_variant_records_uniqueness ON public.active_storage_variant_records USING btree (blob_id, variation_digest);


--
-- Name: index_areas_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_areas_on_user_id ON public.areas USING btree (user_id);


--
-- Name: index_countries_on_geom; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_geom ON public.countries USING gist (geom);


--
-- Name: index_countries_on_iso_a2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_iso_a2 ON public.countries USING btree (iso_a2);


--
-- Name: index_countries_on_iso_a3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_iso_a3 ON public.countries USING btree (iso_a3);


--
-- Name: index_countries_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_name ON public.countries USING btree (name);


--
-- Name: index_digests_on_period_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_digests_on_period_type ON public.digests USING btree (period_type);


--
-- Name: index_digests_on_sharing_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_digests_on_sharing_uuid ON public.digests USING btree (sharing_uuid);


--
-- Name: index_digests_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_digests_on_user_id ON public.digests USING btree (user_id);


--
-- Name: index_digests_on_user_year_month_period_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_digests_on_user_year_month_period_type ON public.digests USING btree (user_id, year, month, period_type);


--
-- Name: index_digests_on_user_year_period_type_monthless; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_digests_on_user_year_period_type_monthless ON public.digests USING btree (user_id, year, period_type) WHERE (month IS NULL);


--
-- Name: index_digests_on_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_digests_on_year ON public.digests USING btree (year);


--
-- Name: index_exports_on_file_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_exports_on_file_type ON public.exports USING btree (file_type);


--
-- Name: index_exports_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_exports_on_status ON public.exports USING btree (status);


--
-- Name: index_exports_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_exports_on_user_id ON public.exports USING btree (user_id);


--
-- Name: index_families_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_families_on_creator_id ON public.families USING btree (creator_id);


--
-- Name: index_family_invitations_on_family_id_and_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_family_id_and_email ON public.family_invitations USING btree (family_id, email);


--
-- Name: index_family_invitations_on_family_status_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_family_status_expires ON public.family_invitations USING btree (family_id, status, expires_at);


--
-- Name: index_family_invitations_on_status_and_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_status_and_expires_at ON public.family_invitations USING btree (status, expires_at);


--
-- Name: index_family_invitations_on_status_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_status_and_updated_at ON public.family_invitations USING btree (status, updated_at);


--
-- Name: index_family_invitations_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_family_invitations_on_token ON public.family_invitations USING btree (token);


--
-- Name: index_family_location_requests_on_family_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_location_requests_on_family_id ON public.family_location_requests USING btree (family_id);


--
-- Name: index_family_memberships_on_family_and_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_memberships_on_family_and_role ON public.family_memberships USING btree (family_id, role);


--
-- Name: index_family_memberships_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_family_memberships_on_user_id ON public.family_memberships USING btree (user_id);


--
-- Name: index_flights_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_flights_on_user_id ON public.flights USING btree (user_id);


--
-- Name: index_flights_on_user_id_and_departure_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_flights_on_user_id_and_departure_time ON public.flights USING btree (user_id, departure_time);


--
-- Name: index_flights_on_user_id_and_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_flights_on_user_id_and_external_id ON public.flights USING btree (user_id, external_id);


--
-- Name: index_flipper_features_on_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_flipper_features_on_key ON public.flipper_features USING btree (key);


--
-- Name: index_flipper_gates_on_feature_key_and_key_and_value; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_flipper_gates_on_feature_key_and_key_and_value ON public.flipper_gates USING btree (feature_key, key, value);


--
-- Name: index_imports_on_additional_data_extraction_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_imports_on_additional_data_extraction_status ON public.imports USING btree (additional_data_extraction_status);


--
-- Name: index_imports_on_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_imports_on_source ON public.imports USING btree (source);


--
-- Name: index_imports_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_imports_on_status ON public.imports USING btree (status);


--
-- Name: index_imports_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_imports_on_user_id ON public.imports USING btree (user_id);


--
-- Name: index_notes_on_attachable_and_noted_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notes_on_attachable_and_noted_date ON public.notes USING btree (attachable_type, attachable_id, ((noted_at)::date)) WHERE (attachable_id IS NOT NULL);


--
-- Name: index_notes_on_attachable_type_and_attachable_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notes_on_attachable_type_and_attachable_id ON public.notes USING btree (attachable_type, attachable_id);


--
-- Name: index_notes_on_lonlat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notes_on_lonlat ON public.notes USING gist (lonlat);


--
-- Name: index_notes_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notes_on_user_id ON public.notes USING btree (user_id);


--
-- Name: index_notes_on_user_id_and_noted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notes_on_user_id_and_noted_at ON public.notes USING btree (user_id, noted_at);


--
-- Name: index_notifications_on_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_kind ON public.notifications USING btree (kind);


--
-- Name: index_notifications_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_user_id ON public.notifications USING btree (user_id);


--
-- Name: index_pending_imports_on_claim_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_pending_imports_on_claim_ticket ON public.pending_imports USING btree (claim_ticket);


--
-- Name: index_pending_imports_on_claimed_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_pending_imports_on_claimed_by_user_id ON public.pending_imports USING btree (claimed_by_user_id);


--
-- Name: index_pending_imports_on_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_pending_imports_on_expires_at ON public.pending_imports USING btree (expires_at);


--
-- Name: index_place_visits_on_place_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_place_visits_on_place_id ON public.place_visits USING btree (place_id);


--
-- Name: index_places_on_demo_true; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_places_on_demo_true ON public.places USING btree (demo) WHERE (demo = true);


--
-- Name: index_places_on_geodata_osm_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_places_on_geodata_osm_id ON public.places USING btree ((((geodata -> 'properties'::text) ->> 'osm_id'::text)));


--
-- Name: index_places_on_lonlat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_places_on_lonlat ON public.places USING gist (lonlat);


--
-- Name: index_places_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_places_on_user_id ON public.places USING btree (user_id);


--
-- Name: index_point_sources_on_digest; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_point_sources_on_digest ON public.point_sources USING btree (digest);


--
-- Name: index_points_on_import_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_import_id ON public.points USING btree (import_id);


--
-- Name: index_points_on_lonlat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_lonlat ON public.points USING gist (lonlat);


--
-- Name: index_points_on_not_reverse_geocoded; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_not_reverse_geocoded ON public.points USING btree (id) WHERE (reverse_geocoded_at IS NULL);


--
-- Name: index_points_on_raw_data_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_raw_data_archive_id ON public.points USING btree (raw_data_archive_id);


--
-- Name: index_points_on_unarchived; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_unarchived ON public.points USING btree (user_id, id) WHERE ((raw_data_archived = false) AND (raw_data <> '{}'::jsonb));


--
-- Name: index_points_on_user_id_timestamp_lonlat; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_points_on_user_id_timestamp_lonlat ON public.points USING btree (user_id, "timestamp", lonlat);


--
-- Name: index_points_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_visit_id ON public.points USING btree (visit_id);


--
-- Name: index_points_raw_data_archives_on_archived_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_raw_data_archives_on_archived_at ON public.points_raw_data_archives USING btree (archived_at);


--
-- Name: index_points_raw_data_archives_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_raw_data_archives_on_user_id ON public.points_raw_data_archives USING btree (user_id);


--
-- Name: index_points_raw_data_archives_on_user_id_and_year_and_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_raw_data_archives_on_user_id_and_year_and_month ON public.points_raw_data_archives USING btree (user_id, year, month);


--
-- Name: index_posters_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_posters_on_user_id ON public.posters USING btree (user_id);


--
-- Name: index_raw_data_archives_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_raw_data_archives_uniqueness ON public.points_raw_data_archives USING btree (user_id, year, month, chunk_number);


--
-- Name: index_route_videos_on_user_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_route_videos_on_user_id_and_created_at ON public.route_videos USING btree (user_id, created_at);


--
-- Name: index_service_settings_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_settings_on_user_id ON public.service_settings USING btree (user_id);


--
-- Name: index_service_settings_on_user_id_and_service_and_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_service_settings_on_user_id_and_service_and_provider ON public.service_settings USING btree (user_id, service, provider);


--
-- Name: index_service_settings_on_user_service_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_service_settings_on_user_service_active ON public.service_settings USING btree (user_id, service) WHERE active;


--
-- Name: index_shared_links_active_by_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_shared_links_active_by_user ON public.shared_links USING btree (user_id) WHERE (revoked_at IS NULL);


--
-- Name: index_shared_links_on_resource_type_and_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_shared_links_on_resource_type_and_resource_id ON public.shared_links USING btree (resource_type, resource_id) WHERE (resource_id IS NOT NULL);


--
-- Name: index_shared_links_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_shared_links_on_user_id ON public.shared_links USING btree (user_id);


--
-- Name: index_stats_on_distance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_distance ON public.stats USING btree (distance);


--
-- Name: index_stats_on_h3_hex_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_h3_hex_ids ON public.stats USING gin (h3_hex_ids) WHERE ((h3_hex_ids IS NOT NULL) AND (h3_hex_ids <> '{}'::jsonb));


--
-- Name: index_stats_on_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_month ON public.stats USING btree (month);


--
-- Name: index_stats_on_sharing_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_stats_on_sharing_uuid ON public.stats USING btree (sharing_uuid);


--
-- Name: index_stats_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_user_id ON public.stats USING btree (user_id);


--
-- Name: index_stats_on_user_id_year_month; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_stats_on_user_id_year_month ON public.stats USING btree (user_id, year, month);


--
-- Name: index_stats_on_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_year ON public.stats USING btree (year);


--
-- Name: index_taggings_on_tag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_taggings_on_tag_id ON public.taggings USING btree (tag_id);


--
-- Name: index_taggings_on_taggable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_taggings_on_taggable ON public.taggings USING btree (taggable_type, taggable_id);


--
-- Name: index_taggings_on_taggable_and_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_taggings_on_taggable_and_tag ON public.taggings USING btree (taggable_type, taggable_id, tag_id);


--
-- Name: index_tags_on_demo_true; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tags_on_demo_true ON public.tags USING btree (demo) WHERE (demo = true);


--
-- Name: index_tags_on_privacy_radius_meters; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tags_on_privacy_radius_meters ON public.tags USING btree (privacy_radius_meters) WHERE (privacy_radius_meters IS NOT NULL);


--
-- Name: index_tags_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tags_on_user_id ON public.tags USING btree (user_id);


--
-- Name: index_tags_on_user_id_and_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tags_on_user_id_and_name ON public.tags USING btree (user_id, name);


--
-- Name: index_track_segments_on_corrected_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_track_segments_on_corrected_at ON public.track_segments USING btree (corrected_at) WHERE (corrected_at IS NOT NULL);


--
-- Name: index_track_segments_on_track_and_indices; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_track_segments_on_track_and_indices ON public.track_segments USING btree (track_id, start_index, end_index);


--
-- Name: index_track_segments_on_track_id_and_transportation_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_track_segments_on_track_id_and_transportation_mode ON public.track_segments USING btree (track_id, transportation_mode);


--
-- Name: index_tracks_on_demo_true; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tracks_on_demo_true ON public.tracks USING btree (demo) WHERE (demo = true);


--
-- Name: index_tracks_on_dominant_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tracks_on_dominant_mode ON public.tracks USING btree (dominant_mode);


--
-- Name: index_tracks_on_original_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tracks_on_original_path ON public.tracks USING gist (original_path);


--
-- Name: index_tracks_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tracks_on_user_id ON public.tracks USING btree (user_id);


--
-- Name: index_tracks_on_user_tracker_start_end_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tracks_on_user_tracker_start_end_unique ON public.tracks USING btree (user_id, COALESCE(tracker_id, ''::character varying), start_at, end_at);


--
-- Name: index_trips_on_demo_true; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_trips_on_demo_true ON public.trips USING btree (demo) WHERE (demo = true);


--
-- Name: index_trips_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_trips_on_user_id ON public.trips USING btree (user_id);


--
-- Name: index_users_on_api_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_api_key ON public.users USING btree (api_key);


--
-- Name: index_users_on_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_otp_locked_at_not_null; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_otp_locked_at_not_null ON public.users USING btree (otp_locked_at) WHERE (otp_locked_at IS NOT NULL);


--
-- Name: index_users_on_plan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_plan ON public.users USING btree (plan);


--
-- Name: index_users_on_provider_and_uid_present; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_provider_and_uid_present ON public.users USING btree (provider, uid) WHERE ((provider IS NOT NULL) AND (uid IS NOT NULL));


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_users_on_signup_variant_reverse_trial; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_signup_variant_reverse_trial ON public.users USING btree (signup_variant) WHERE ((signup_variant)::text = 'reverse_trial'::text);


--
-- Name: index_users_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_status ON public.users USING btree (status);


--
-- Name: index_users_on_unlock_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_unlock_token ON public.users USING btree (unlock_token);


--
-- Name: index_users_on_visits_redetected_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_visits_redetected_at ON public.users USING btree (visits_redetected_at);


--
-- Name: index_visits_on_area_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_area_id ON public.visits USING btree (area_id);


--
-- Name: index_visits_on_demo_true; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_demo_true ON public.visits USING btree (demo) WHERE (demo = true);


--
-- Name: index_visits_on_place_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_place_id ON public.visits USING btree (place_id);


--
-- Name: index_visits_on_started_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_started_at ON public.visits USING btree (started_at);


--
-- Name: index_visits_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_user_id ON public.visits USING btree (user_id);


--
-- Name: route_videos fk_rails_02b56b6dae; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route_videos
    ADD CONSTRAINT fk_rails_02b56b6dae FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: visits fk_rails_09e5e7c20b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_09e5e7c20b FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shared_links fk_rails_1b04e35c4c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_links
    ADD CONSTRAINT fk_rails_1b04e35c4c FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: points fk_rails_206a3ea05e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT fk_rails_206a3ea05e FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: points fk_rails_22278038dd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT fk_rails_22278038dd FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: families fk_rails_3ef59c2ec7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT fk_rails_3ef59c2ec7 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: place_visits fk_rails_5237b3cc14; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits
    ADD CONSTRAINT fk_rails_5237b3cc14 FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- Name: visits fk_rails_5e6ebcb55c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_5e6ebcb55c FOREIGN KEY (area_id) REFERENCES public.areas(id);


--
-- Name: areas fk_rails_64ba63583c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT fk_rails_64ba63583c FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pending_imports fk_rails_67c288c383; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_imports
    ADD CONSTRAINT fk_rails_67c288c383 FOREIGN KEY (claimed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: trips fk_rails_6a33c9e4ea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT fk_rails_6a33c9e4ea FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notes fk_rails_7f2323ad43; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT fk_rails_7f2323ad43 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: family_memberships fk_rails_818aa4a9f9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships
    ADD CONSTRAINT fk_rails_818aa4a9f9 FOREIGN KEY (family_id) REFERENCES public.families(id);


--
-- Name: family_memberships fk_rails_829cfb2ffc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships
    ADD CONSTRAINT fk_rails_829cfb2ffc FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: family_invitations fk_rails_943507cd04; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations
    ADD CONSTRAINT fk_rails_943507cd04 FOREIGN KEY (family_id) REFERENCES public.families(id);


--
-- Name: points fk_rails_98d7bdf4ad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT fk_rails_98d7bdf4ad FOREIGN KEY (raw_data_archive_id) REFERENCES public.points_raw_data_archives(id) ON DELETE RESTRICT;


--
-- Name: active_storage_variant_records fk_rails_993965df05; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT fk_rails_993965df05 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: stats fk_rails_9e94901167; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT fk_rails_9e94901167 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: taggings fk_rails_9fcd2e236b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggings
    ADD CONSTRAINT fk_rails_9fcd2e236b FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: family_location_requests fk_rails_a52bcdbc28; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_location_requests
    ADD CONSTRAINT fk_rails_a52bcdbc28 FOREIGN KEY (family_id) REFERENCES public.families(id);


--
-- Name: tracks fk_rails_a9ae83adcc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT fk_rails_a9ae83adcc FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications fk_rails_b080fb4855; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_b080fb4855 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: service_settings fk_rails_bcdd50bba4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_settings
    ADD CONSTRAINT fk_rails_bcdd50bba4 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: active_storage_attachments fk_rails_c3b3935057; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT fk_rails_c3b3935057 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: visits fk_rails_ceb146b88d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_ceb146b88d FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- Name: family_invitations fk_rails_d2f7db596b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations
    ADD CONSTRAINT fk_rails_d2f7db596b FOREIGN KEY (invited_by_id) REFERENCES public.users(id);


--
-- Name: family_location_requests fk_rails_d78ba34bd1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_location_requests
    ADD CONSTRAINT fk_rails_d78ba34bd1 FOREIGN KEY (target_user_id) REFERENCES public.users(id);


--
-- Name: points_raw_data_archives fk_rails_dc90211ee5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_raw_data_archives
    ADD CONSTRAINT fk_rails_dc90211ee5 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tags fk_rails_e689f6d0cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_rails_e689f6d0cc FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: digests fk_rails_ebdc1fb287; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digests
    ADD CONSTRAINT fk_rails_ebdc1fb287 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: track_segments fk_rails_ef0fcf83b4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.track_segments
    ADD CONSTRAINT fk_rails_ef0fcf83b4 FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: posters fk_rails_f1941d801b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posters
    ADD CONSTRAINT fk_rails_f1941d801b FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: flights fk_rails_f23525dbb0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT fk_rails_f23525dbb0 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: family_location_requests fk_rails_f607841cdd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_location_requests
    ADD CONSTRAINT fk_rails_f607841cdd FOREIGN KEY (requester_id) REFERENCES public.users(id);


--
-- Name: place_visits fk_rails_fa8b68cd0c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits
    ADD CONSTRAINT fk_rails_fa8b68cd0c FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg110+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	production	2026-09-24 01:36:38.62189	2026-09-24 01:36:38.621892
\.


--
-- Data for Name: data_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_migrations (version) FROM stdin;
20240525110530
20240625201842
20240713103122
20240724141417
20240730130922
20240808133112
20240815174852
20240822094532
20241022100309
20241107112451
20241202125248
20241206163450
20250104204852
20250123151849
20250226192005
20250303194123
20250403204658
20250404182629
20250516180933
20250518173936
20250518174305
20250704185707
20250709195003
20250720171241
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
20220325100310
20231021104256
20231021104257
20231021104258
20240315213523
20240315215423
20240317171559
20240323125126
20240323160300
20240323161049
20240323190039
20240324161309
20240324161800
20240324173315
20240404154959
20240425200155
20240518095848
20240525110244
20240612152451
20240620205120
20240630093005
20240703105734
20240712141303
20240713103051
20240721165313
20240721183005
20240721183116
20240805150111
20240808102348
20240808102425
20240808121027
20240822092405
20241127161621
20241128095325
20241202114820
20241205160055
20241211113119
20241226202204
20241226202831
20250120152014
20250120152540
20250120154555
20250123145155
20250123151657
20250219195822
20250221181805
20250221185032
20250221194430
20250221194509
20250303194009
20250303194043
20250324180755
20250404182437
20250513164521
20250515190752
20250515192211
20250625185030
20250627184017
20250703193656
20250703193657
20250721204404
20250723164055
20250728191359
20250821192219
20250823125940
20250905120121
20250910224538
20250910224714
20250918215512
20250926220114
20250926220135
20250926220158
20250926220345
20251028130433
20251030190924
20251116184506
20251116184514
20251116184520
20251118204141
20251118210506
20251201192510
20251206000001
20251206000002
20251206000004
20251208210410
20251210193532
20251226170919
20251227000001
20251227223614
20251228000000
20251228100000
20260103114630
20260108192905
20260112192240
20260113230537
20260120193124
20260120193200
20260120193336
20260120193401
20260120193501
20260124221434
20260125100000
20260201000001
20260201000002
20260206202634
20260207075817
20260208223255
20260216190000
20260217000000
20260217000001
20260222215414
20260301201446
20260301202147
20260310000001
20260310000002
20260310000003
20260310000006
20260313134546
20260314000001
20260315000001
20260318000001
20260320000001
20260320000002
20260322000001
20260322000002
20260323000001
20260323000002
20260325183025
20260326192648
20260328205912
20260328210500
20260420190307
20260420211352
20260421200001
20260421200002
20260421230359
20260426204917
20260428200000
20260429180000
20260430000001
20260503111800
20260504120000
20260508030000
20260508093702
20260508120000
20260508120100
20260508193900
20260508193923
20260509163901
20260514120000
20260514120100
20260520111503
20260521121115
20260521121527
20260521223000
20260528102209
20260528102210
20260528102211
20260528102212
20260529120000
20260529185458
20260531000000
20260602125716
20260604120000
20260610090000
20260611135333
20260622090000
20260714090000
20260719180000
20260719185000
20260719190000
20260727120000
20260727130000
20260730160000
20260730200000
20260730210000
20260730210100
20260730210150
20260730210200
20260730210250
20260730210300
20260730210400
20260730220000
20260802120000
20260804085722
20260804085723
20260804093200
20260805120000
20260805120001
20260808120000
20260809085900
20260809085930
20260809090000
20260809090100
20260811120000
20260813120000
20260813120100
20260815100000
20260815100001
20260816120000
20260816150000
20260816150100
20260816150200
20260818201239
20260819120000
20260819120100
20260823190000
20260825120000
20260825120100
\.


--
-- PostgreSQL database dump complete
--

