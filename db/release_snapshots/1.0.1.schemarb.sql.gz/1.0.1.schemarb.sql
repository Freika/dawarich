--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg110+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_text_rich_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.action_text_rich_texts (
    id bigint NOT NULL,
    name character varying NOT NULL,
    body text,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.action_text_rich_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.action_text_rich_texts_id_seq OWNED BY public.action_text_rich_texts.id;


--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_attachments (
    id bigint NOT NULL,
    name character varying NOT NULL,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    blob_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_attachments_id_seq OWNED BY public.active_storage_attachments.id;


--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_blobs (
    id bigint NOT NULL,
    key character varying NOT NULL,
    filename character varying NOT NULL,
    content_type character varying,
    metadata text,
    service_name character varying NOT NULL,
    byte_size bigint NOT NULL,
    checksum character varying,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_blobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_blobs_id_seq OWNED BY public.active_storage_blobs.id;


--
-- Name: active_storage_variant_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_variant_records (
    id bigint NOT NULL,
    blob_id bigint NOT NULL,
    variation_digest character varying NOT NULL
);


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_variant_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_variant_records_id_seq OWNED BY public.active_storage_variant_records.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.areas (
    id bigint NOT NULL,
    name character varying NOT NULL,
    user_id bigint NOT NULL,
    longitude numeric(10,6) NOT NULL,
    latitude numeric(10,6) NOT NULL,
    radius integer NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: areas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.areas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.areas_id_seq OWNED BY public.areas.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    id bigint NOT NULL,
    name character varying NOT NULL,
    iso_a2 character varying NOT NULL,
    iso_a3 character varying NOT NULL,
    geom public.geometry(MultiPolygon,4326),
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: data_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_migrations (
    version character varying NOT NULL
);


--
-- Name: digests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digests (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    year integer NOT NULL,
    period_type integer DEFAULT 0 NOT NULL,
    distance bigint DEFAULT 0 NOT NULL,
    toponyms jsonb DEFAULT '{}'::jsonb,
    monthly_distances jsonb DEFAULT '{}'::jsonb,
    time_spent_by_location jsonb DEFAULT '{}'::jsonb,
    first_time_visits jsonb DEFAULT '{}'::jsonb,
    year_over_year jsonb DEFAULT '{}'::jsonb,
    all_time_stats jsonb DEFAULT '{}'::jsonb,
    sharing_settings jsonb DEFAULT '{}'::jsonb,
    sharing_uuid uuid,
    sent_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: digests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digests_id_seq OWNED BY public.digests.id;


--
-- Name: exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exports (
    id bigint NOT NULL,
    name character varying NOT NULL,
    url character varying,
    status integer DEFAULT 0 NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    file_format integer DEFAULT 0,
    start_at timestamp(6) without time zone,
    end_at timestamp(6) without time zone,
    file_type integer DEFAULT 0 NOT NULL
);


--
-- Name: exports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exports_id_seq OWNED BY public.exports.id;


--
-- Name: families; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.families (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: families_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.families_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: families_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.families_id_seq OWNED BY public.families.id;


--
-- Name: family_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.family_invitations (
    id bigint NOT NULL,
    family_id bigint NOT NULL,
    email character varying NOT NULL,
    token character varying NOT NULL,
    expires_at timestamp(6) without time zone NOT NULL,
    invited_by_id bigint NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: family_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.family_invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: family_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.family_invitations_id_seq OWNED BY public.family_invitations.id;


--
-- Name: family_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.family_memberships (
    id bigint NOT NULL,
    family_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: family_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.family_memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: family_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.family_memberships_id_seq OWNED BY public.family_memberships.id;


--
-- Name: imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imports (
    id bigint NOT NULL,
    name character varying NOT NULL,
    user_id bigint NOT NULL,
    source integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    raw_points integer DEFAULT 0,
    doubles integer DEFAULT 0,
    processed integer DEFAULT 0,
    raw_data jsonb,
    points_count integer DEFAULT 0,
    status integer DEFAULT 0 NOT NULL
);


--
-- Name: imports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.imports_id_seq OWNED BY public.imports.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    title character varying NOT NULL,
    content text NOT NULL,
    user_id bigint NOT NULL,
    kind integer DEFAULT 0 NOT NULL,
    read_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: place_visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.place_visits (
    id bigint NOT NULL,
    place_id bigint NOT NULL,
    visit_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: place_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.place_visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: place_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.place_visits_id_seq OWNED BY public.place_visits.id;


--
-- Name: places; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.places (
    id bigint NOT NULL,
    name character varying NOT NULL,
    longitude numeric(10,6) NOT NULL,
    latitude numeric(10,6) NOT NULL,
    city character varying,
    country character varying,
    source integer DEFAULT 0,
    geodata jsonb DEFAULT '{}'::jsonb NOT NULL,
    reverse_geocoded_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    lonlat public.geography(Point,4326),
    user_id bigint,
    note text
);


--
-- Name: places_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.places_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: places_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.places_id_seq OWNED BY public.places.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id bigint NOT NULL,
    battery_status integer,
    ping character varying,
    battery integer,
    tracker_id character varying,
    topic character varying,
    altitude integer,
    longitude numeric(10,6),
    velocity character varying,
    trigger integer,
    bssid character varying,
    ssid character varying,
    connection integer,
    vertical_accuracy integer,
    accuracy integer,
    "timestamp" integer,
    latitude numeric(10,6),
    mode integer,
    inrids text[] DEFAULT '{}'::text[],
    in_regions text[] DEFAULT '{}'::text[],
    raw_data jsonb DEFAULT '{}'::jsonb,
    import_id bigint,
    city character varying,
    country character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint,
    geodata jsonb DEFAULT '{}'::jsonb NOT NULL,
    visit_id bigint,
    reverse_geocoded_at timestamp(6) without time zone,
    course numeric(8,5),
    course_accuracy numeric(8,5),
    external_track_id character varying,
    lonlat public.geography(Point,4326),
    country_id bigint,
    track_id bigint,
    country_name character varying,
    raw_data_archived boolean DEFAULT false NOT NULL,
    raw_data_archive_id bigint
);


--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_id_seq OWNED BY public.points.id;


--
-- Name: points_raw_data_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points_raw_data_archives (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    chunk_number integer DEFAULT 1 NOT NULL,
    point_count integer NOT NULL,
    point_ids_checksum character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    archived_at timestamp(6) without time zone NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    verified_at timestamp(6) without time zone
);


--
-- Name: points_raw_data_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_raw_data_archives_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points_raw_data_archives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.points_raw_data_archives_id_seq OWNED BY public.points_raw_data_archives.id;


--
-- Name: rails_pulse_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rails_pulse_operations (
    id bigint NOT NULL,
    request_id bigint NOT NULL,
    query_id bigint,
    operation_type character varying NOT NULL,
    label character varying NOT NULL,
    duration numeric(15,6) NOT NULL,
    codebase_location character varying,
    start_time double precision DEFAULT 0.0 NOT NULL,
    occurred_at timestamp without time zone NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: COLUMN rails_pulse_operations.request_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.request_id IS 'Link to the request';


--
-- Name: COLUMN rails_pulse_operations.query_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.query_id IS 'Link to the normalized SQL query';


--
-- Name: COLUMN rails_pulse_operations.operation_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.operation_type IS 'Type of operation (e.g., database, view, gem_call)';


--
-- Name: COLUMN rails_pulse_operations.label; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.label IS 'Descriptive name (e.g., SELECT FROM users WHERE id = 1, render layout)';


--
-- Name: COLUMN rails_pulse_operations.duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.duration IS 'Operation duration in milliseconds';


--
-- Name: COLUMN rails_pulse_operations.codebase_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.codebase_location IS 'File and line number (e.g., app/models/user.rb:25)';


--
-- Name: COLUMN rails_pulse_operations.start_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.start_time IS 'Operation start time in milliseconds';


--
-- Name: COLUMN rails_pulse_operations.occurred_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_operations.occurred_at IS 'When the request started';


--
-- Name: rails_pulse_operations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rails_pulse_operations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rails_pulse_operations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rails_pulse_operations_id_seq OWNED BY public.rails_pulse_operations.id;


--
-- Name: rails_pulse_queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rails_pulse_queries (
    id bigint NOT NULL,
    normalized_sql character varying(1000) NOT NULL,
    analyzed_at timestamp(6) without time zone,
    explain_plan text,
    issues text,
    metadata text,
    query_stats text,
    backtrace_analysis text,
    index_recommendations text,
    n_plus_one_analysis text,
    suggestions text,
    tags text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: COLUMN rails_pulse_queries.normalized_sql; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.normalized_sql IS 'Normalized SQL query string (e.g., SELECT * FROM users WHERE id = ?)';


--
-- Name: COLUMN rails_pulse_queries.analyzed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.analyzed_at IS 'When query analysis was last performed';


--
-- Name: COLUMN rails_pulse_queries.explain_plan; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.explain_plan IS 'EXPLAIN output from actual SQL execution';


--
-- Name: COLUMN rails_pulse_queries.issues; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.issues IS 'JSON array of detected performance issues';


--
-- Name: COLUMN rails_pulse_queries.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.metadata IS 'JSON object containing query complexity metrics';


--
-- Name: COLUMN rails_pulse_queries.query_stats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.query_stats IS 'JSON object with query characteristics analysis';


--
-- Name: COLUMN rails_pulse_queries.backtrace_analysis; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.backtrace_analysis IS 'JSON object with call chain and N+1 detection';


--
-- Name: COLUMN rails_pulse_queries.index_recommendations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.index_recommendations IS 'JSON array of database index recommendations';


--
-- Name: COLUMN rails_pulse_queries.n_plus_one_analysis; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.n_plus_one_analysis IS 'JSON object with enhanced N+1 query detection results';


--
-- Name: COLUMN rails_pulse_queries.suggestions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.suggestions IS 'JSON array of optimization recommendations';


--
-- Name: COLUMN rails_pulse_queries.tags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_queries.tags IS 'JSON array of tags for filtering and categorization';


--
-- Name: rails_pulse_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rails_pulse_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rails_pulse_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rails_pulse_queries_id_seq OWNED BY public.rails_pulse_queries.id;


--
-- Name: rails_pulse_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rails_pulse_requests (
    id bigint NOT NULL,
    route_id bigint NOT NULL,
    duration numeric(15,6) NOT NULL,
    status integer NOT NULL,
    is_error boolean DEFAULT false NOT NULL,
    request_uuid character varying NOT NULL,
    controller_action character varying,
    occurred_at timestamp without time zone NOT NULL,
    tags text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: COLUMN rails_pulse_requests.route_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.route_id IS 'Link to the route';


--
-- Name: COLUMN rails_pulse_requests.duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.duration IS 'Total request duration in milliseconds';


--
-- Name: COLUMN rails_pulse_requests.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.status IS 'HTTP status code (e.g., 200, 500)';


--
-- Name: COLUMN rails_pulse_requests.is_error; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.is_error IS 'True if status >= 500';


--
-- Name: COLUMN rails_pulse_requests.request_uuid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.request_uuid IS 'Unique identifier for the request (e.g., UUID)';


--
-- Name: COLUMN rails_pulse_requests.controller_action; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.controller_action IS 'Controller and action handling the request (e.g., PostsController#show)';


--
-- Name: COLUMN rails_pulse_requests.occurred_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.occurred_at IS 'When the request started';


--
-- Name: COLUMN rails_pulse_requests.tags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_requests.tags IS 'JSON array of tags for filtering and categorization';


--
-- Name: rails_pulse_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rails_pulse_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rails_pulse_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rails_pulse_requests_id_seq OWNED BY public.rails_pulse_requests.id;


--
-- Name: rails_pulse_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rails_pulse_routes (
    id bigint NOT NULL,
    method character varying NOT NULL,
    path character varying NOT NULL,
    tags text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: COLUMN rails_pulse_routes.method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_routes.method IS 'HTTP method (e.g., GET, POST)';


--
-- Name: COLUMN rails_pulse_routes.path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_routes.path IS 'Request path (e.g., /posts/index)';


--
-- Name: COLUMN rails_pulse_routes.tags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_routes.tags IS 'JSON array of tags for filtering and categorization';


--
-- Name: rails_pulse_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rails_pulse_routes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rails_pulse_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rails_pulse_routes_id_seq OWNED BY public.rails_pulse_routes.id;


--
-- Name: rails_pulse_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rails_pulse_summaries (
    id bigint NOT NULL,
    period_start timestamp(6) without time zone NOT NULL,
    period_end timestamp(6) without time zone NOT NULL,
    period_type character varying NOT NULL,
    summarizable_type character varying NOT NULL,
    summarizable_id bigint NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    avg_duration double precision,
    min_duration double precision,
    max_duration double precision,
    p50_duration double precision,
    p95_duration double precision,
    p99_duration double precision,
    total_duration double precision,
    stddev_duration double precision,
    error_count integer DEFAULT 0,
    success_count integer DEFAULT 0,
    status_2xx integer DEFAULT 0,
    status_3xx integer DEFAULT 0,
    status_4xx integer DEFAULT 0,
    status_5xx integer DEFAULT 0,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: COLUMN rails_pulse_summaries.period_start; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.period_start IS 'Start of the aggregation period';


--
-- Name: COLUMN rails_pulse_summaries.period_end; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.period_end IS 'End of the aggregation period';


--
-- Name: COLUMN rails_pulse_summaries.period_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.period_type IS 'Aggregation period type: hour, day, week, month';


--
-- Name: COLUMN rails_pulse_summaries.summarizable_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.summarizable_id IS 'Link to Route or Query';


--
-- Name: COLUMN rails_pulse_summaries.count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.count IS 'Total number of requests/operations';


--
-- Name: COLUMN rails_pulse_summaries.avg_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.avg_duration IS 'Average duration in milliseconds';


--
-- Name: COLUMN rails_pulse_summaries.min_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.min_duration IS 'Minimum duration in milliseconds';


--
-- Name: COLUMN rails_pulse_summaries.max_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.max_duration IS 'Maximum duration in milliseconds';


--
-- Name: COLUMN rails_pulse_summaries.p50_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.p50_duration IS '50th percentile duration';


--
-- Name: COLUMN rails_pulse_summaries.p95_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.p95_duration IS '95th percentile duration';


--
-- Name: COLUMN rails_pulse_summaries.p99_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.p99_duration IS '99th percentile duration';


--
-- Name: COLUMN rails_pulse_summaries.total_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.total_duration IS 'Total duration in milliseconds';


--
-- Name: COLUMN rails_pulse_summaries.stddev_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.stddev_duration IS 'Standard deviation of duration';


--
-- Name: COLUMN rails_pulse_summaries.error_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.error_count IS 'Number of error responses (5xx)';


--
-- Name: COLUMN rails_pulse_summaries.success_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.success_count IS 'Number of successful responses';


--
-- Name: COLUMN rails_pulse_summaries.status_2xx; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.status_2xx IS 'Number of 2xx responses';


--
-- Name: COLUMN rails_pulse_summaries.status_3xx; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.status_3xx IS 'Number of 3xx responses';


--
-- Name: COLUMN rails_pulse_summaries.status_4xx; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.status_4xx IS 'Number of 4xx responses';


--
-- Name: COLUMN rails_pulse_summaries.status_5xx; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rails_pulse_summaries.status_5xx IS 'Number of 5xx responses';


--
-- Name: rails_pulse_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rails_pulse_summaries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rails_pulse_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rails_pulse_summaries_id_seq OWNED BY public.rails_pulse_summaries.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stats (
    id bigint NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    distance integer NOT NULL,
    toponyms jsonb,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint NOT NULL,
    daily_distance jsonb DEFAULT '{}'::jsonb,
    sharing_settings jsonb DEFAULT '{}'::jsonb,
    sharing_uuid uuid,
    h3_hex_ids jsonb DEFAULT '{}'::jsonb
);


--
-- Name: stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stats_id_seq OWNED BY public.stats.id;


--
-- Name: taggings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggings (
    id bigint NOT NULL,
    taggable_type character varying NOT NULL,
    taggable_id bigint NOT NULL,
    tag_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: taggings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taggings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taggings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taggings_id_seq OWNED BY public.taggings.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name character varying NOT NULL,
    icon character varying,
    color character varying,
    user_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    privacy_radius_meters integer
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: tracks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracks (
    id bigint NOT NULL,
    start_at timestamp(6) without time zone NOT NULL,
    end_at timestamp(6) without time zone NOT NULL,
    user_id bigint NOT NULL,
    original_path public.geometry(LineString) NOT NULL,
    distance numeric(8,2),
    avg_speed double precision,
    duration integer,
    elevation_gain integer,
    elevation_loss integer,
    elevation_max integer,
    elevation_min integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tracks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tracks_id_seq OWNED BY public.tracks.id;


--
-- Name: trips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trips (
    id bigint NOT NULL,
    name character varying NOT NULL,
    started_at timestamp(6) without time zone NOT NULL,
    ended_at timestamp(6) without time zone NOT NULL,
    distance integer,
    user_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    path public.geometry(LineString,3857),
    visited_countries jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: trips_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trips_id_seq OWNED BY public.trips.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp(6) without time zone,
    remember_created_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    api_key character varying DEFAULT ''::character varying NOT NULL,
    theme character varying DEFAULT 'dark'::character varying NOT NULL,
    settings jsonb DEFAULT '{"fog_of_war_meters": "100", "meters_between_routes": "1000", "minutes_between_routes": "60"}'::jsonb,
    admin boolean DEFAULT false,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp(6) without time zone,
    last_sign_in_at timestamp(6) without time zone,
    current_sign_in_ip character varying,
    last_sign_in_ip character varying,
    status integer DEFAULT 0,
    active_until timestamp(6) without time zone,
    points_count integer DEFAULT 0 NOT NULL,
    provider character varying,
    uid character varying,
    utm_source character varying,
    utm_medium character varying,
    utm_campaign character varying,
    utm_term character varying,
    utm_content character varying
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    area_id bigint,
    user_id bigint NOT NULL,
    started_at timestamp(6) without time zone NOT NULL,
    ended_at timestamp(6) without time zone NOT NULL,
    duration integer NOT NULL,
    name character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    place_id bigint
);


--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: action_text_rich_texts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.action_text_rich_texts ALTER COLUMN id SET DEFAULT nextval('public.action_text_rich_texts_id_seq'::regclass);


--
-- Name: active_storage_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments ALTER COLUMN id SET DEFAULT nextval('public.active_storage_attachments_id_seq'::regclass);


--
-- Name: active_storage_blobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_blobs ALTER COLUMN id SET DEFAULT nextval('public.active_storage_blobs_id_seq'::regclass);


--
-- Name: active_storage_variant_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records ALTER COLUMN id SET DEFAULT nextval('public.active_storage_variant_records_id_seq'::regclass);


--
-- Name: areas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas ALTER COLUMN id SET DEFAULT nextval('public.areas_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: digests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digests ALTER COLUMN id SET DEFAULT nextval('public.digests_id_seq'::regclass);


--
-- Name: exports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports ALTER COLUMN id SET DEFAULT nextval('public.exports_id_seq'::regclass);


--
-- Name: families id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families ALTER COLUMN id SET DEFAULT nextval('public.families_id_seq'::regclass);


--
-- Name: family_invitations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations ALTER COLUMN id SET DEFAULT nextval('public.family_invitations_id_seq'::regclass);


--
-- Name: family_memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships ALTER COLUMN id SET DEFAULT nextval('public.family_memberships_id_seq'::regclass);


--
-- Name: imports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports ALTER COLUMN id SET DEFAULT nextval('public.imports_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: place_visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits ALTER COLUMN id SET DEFAULT nextval('public.place_visits_id_seq'::regclass);


--
-- Name: places id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places ALTER COLUMN id SET DEFAULT nextval('public.places_id_seq'::regclass);


--
-- Name: points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points ALTER COLUMN id SET DEFAULT nextval('public.points_id_seq'::regclass);


--
-- Name: points_raw_data_archives id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_raw_data_archives ALTER COLUMN id SET DEFAULT nextval('public.points_raw_data_archives_id_seq'::regclass);


--
-- Name: rails_pulse_operations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_operations ALTER COLUMN id SET DEFAULT nextval('public.rails_pulse_operations_id_seq'::regclass);


--
-- Name: rails_pulse_queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_queries ALTER COLUMN id SET DEFAULT nextval('public.rails_pulse_queries_id_seq'::regclass);


--
-- Name: rails_pulse_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_requests ALTER COLUMN id SET DEFAULT nextval('public.rails_pulse_requests_id_seq'::regclass);


--
-- Name: rails_pulse_routes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_routes ALTER COLUMN id SET DEFAULT nextval('public.rails_pulse_routes_id_seq'::regclass);


--
-- Name: rails_pulse_summaries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_summaries ALTER COLUMN id SET DEFAULT nextval('public.rails_pulse_summaries_id_seq'::regclass);


--
-- Name: stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats ALTER COLUMN id SET DEFAULT nextval('public.stats_id_seq'::regclass);


--
-- Name: taggings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggings ALTER COLUMN id SET DEFAULT nextval('public.taggings_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: tracks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracks ALTER COLUMN id SET DEFAULT nextval('public.tracks_id_seq'::regclass);


--
-- Name: trips id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trips ALTER COLUMN id SET DEFAULT nextval('public.trips_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: action_text_rich_texts action_text_rich_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.action_text_rich_texts
    ADD CONSTRAINT action_text_rich_texts_pkey PRIMARY KEY (id);


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: active_storage_variant_records active_storage_variant_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT active_storage_variant_records_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: areas areas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT areas_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: data_migrations data_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_migrations
    ADD CONSTRAINT data_migrations_pkey PRIMARY KEY (version);


--
-- Name: digests digests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digests
    ADD CONSTRAINT digests_pkey PRIMARY KEY (id);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (id);


--
-- Name: families families_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT families_pkey PRIMARY KEY (id);


--
-- Name: family_invitations family_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations
    ADD CONSTRAINT family_invitations_pkey PRIMARY KEY (id);


--
-- Name: family_memberships family_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships
    ADD CONSTRAINT family_memberships_pkey PRIMARY KEY (id);


--
-- Name: imports imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT imports_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: place_visits place_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits
    ADD CONSTRAINT place_visits_pkey PRIMARY KEY (id);


--
-- Name: places places_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_pkey PRIMARY KEY (id);


--
-- Name: points points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_pkey PRIMARY KEY (id);


--
-- Name: points_raw_data_archives points_raw_data_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_raw_data_archives
    ADD CONSTRAINT points_raw_data_archives_pkey PRIMARY KEY (id);


--
-- Name: rails_pulse_operations rails_pulse_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_operations
    ADD CONSTRAINT rails_pulse_operations_pkey PRIMARY KEY (id);


--
-- Name: rails_pulse_queries rails_pulse_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_queries
    ADD CONSTRAINT rails_pulse_queries_pkey PRIMARY KEY (id);


--
-- Name: rails_pulse_requests rails_pulse_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_requests
    ADD CONSTRAINT rails_pulse_requests_pkey PRIMARY KEY (id);


--
-- Name: rails_pulse_routes rails_pulse_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_routes
    ADD CONSTRAINT rails_pulse_routes_pkey PRIMARY KEY (id);


--
-- Name: rails_pulse_summaries rails_pulse_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_summaries
    ADD CONSTRAINT rails_pulse_summaries_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: stats stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT stats_pkey PRIMARY KEY (id);


--
-- Name: taggings taggings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggings
    ADD CONSTRAINT taggings_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tracks tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_pkey PRIMARY KEY (id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: users users_admin_null; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.users
    ADD CONSTRAINT users_admin_null CHECK ((admin IS NOT NULL)) NOT VALID;


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: idx_operations_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_created_at ON public.rails_pulse_operations USING btree (created_at);


--
-- Name: idx_operations_for_aggregation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_for_aggregation ON public.rails_pulse_operations USING btree (created_at, query_id);


--
-- Name: idx_points_track_generation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_points_track_generation ON public.points USING btree (user_id, "timestamp", track_id);


--
-- Name: idx_points_user_city; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_points_user_city ON public.points USING btree (user_id, city);


--
-- Name: idx_points_user_country_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_points_user_country_name ON public.points USING btree (user_id, country_name);


--
-- Name: idx_points_user_visit_null_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_points_user_visit_null_timestamp ON public.points USING btree (user_id, "timestamp") WHERE (visit_id IS NULL);


--
-- Name: idx_pulse_summaries_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_pulse_summaries_unique ON public.rails_pulse_summaries USING btree (summarizable_type, summarizable_id, period_type, period_start);


--
-- Name: idx_requests_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_requests_created_at ON public.rails_pulse_requests USING btree (created_at);


--
-- Name: idx_requests_for_aggregation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_requests_for_aggregation ON public.rails_pulse_requests USING btree (created_at, route_id);


--
-- Name: index_action_text_rich_texts_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_action_text_rich_texts_uniqueness ON public.action_text_rich_texts USING btree (record_type, record_id, name);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_active_storage_variant_records_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_variant_records_uniqueness ON public.active_storage_variant_records USING btree (blob_id, variation_digest);


--
-- Name: index_areas_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_areas_on_user_id ON public.areas USING btree (user_id);


--
-- Name: index_countries_on_geom; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_geom ON public.countries USING gist (geom);


--
-- Name: index_countries_on_iso_a2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_iso_a2 ON public.countries USING btree (iso_a2);


--
-- Name: index_countries_on_iso_a3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_iso_a3 ON public.countries USING btree (iso_a3);


--
-- Name: index_countries_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_countries_on_name ON public.countries USING btree (name);


--
-- Name: index_digests_on_period_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_digests_on_period_type ON public.digests USING btree (period_type);


--
-- Name: index_digests_on_sharing_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_digests_on_sharing_uuid ON public.digests USING btree (sharing_uuid);


--
-- Name: index_digests_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_digests_on_user_id ON public.digests USING btree (user_id);


--
-- Name: index_digests_on_user_id_and_year_and_period_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_digests_on_user_id_and_year_and_period_type ON public.digests USING btree (user_id, year, period_type);


--
-- Name: index_digests_on_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_digests_on_year ON public.digests USING btree (year);


--
-- Name: index_exports_on_file_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_exports_on_file_type ON public.exports USING btree (file_type);


--
-- Name: index_exports_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_exports_on_status ON public.exports USING btree (status);


--
-- Name: index_exports_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_exports_on_user_id ON public.exports USING btree (user_id);


--
-- Name: index_families_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_families_on_creator_id ON public.families USING btree (creator_id);


--
-- Name: index_family_invitations_on_family_id_and_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_family_id_and_email ON public.family_invitations USING btree (family_id, email);


--
-- Name: index_family_invitations_on_family_status_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_family_status_expires ON public.family_invitations USING btree (family_id, status, expires_at);


--
-- Name: index_family_invitations_on_status_and_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_status_and_expires_at ON public.family_invitations USING btree (status, expires_at);


--
-- Name: index_family_invitations_on_status_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_invitations_on_status_and_updated_at ON public.family_invitations USING btree (status, updated_at);


--
-- Name: index_family_invitations_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_family_invitations_on_token ON public.family_invitations USING btree (token);


--
-- Name: index_family_memberships_on_family_and_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_family_memberships_on_family_and_role ON public.family_memberships USING btree (family_id, role);


--
-- Name: index_family_memberships_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_family_memberships_on_user_id ON public.family_memberships USING btree (user_id);


--
-- Name: index_imports_on_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_imports_on_source ON public.imports USING btree (source);


--
-- Name: index_imports_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_imports_on_status ON public.imports USING btree (status);


--
-- Name: index_imports_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_imports_on_user_id ON public.imports USING btree (user_id);


--
-- Name: index_notifications_on_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_kind ON public.notifications USING btree (kind);


--
-- Name: index_notifications_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_user_id ON public.notifications USING btree (user_id);


--
-- Name: index_place_visits_on_place_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_place_visits_on_place_id ON public.place_visits USING btree (place_id);


--
-- Name: index_place_visits_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_place_visits_on_visit_id ON public.place_visits USING btree (visit_id);


--
-- Name: index_places_on_geodata_osm_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_places_on_geodata_osm_id ON public.places USING btree ((((geodata -> 'properties'::text) ->> 'osm_id'::text)));


--
-- Name: index_places_on_lonlat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_places_on_lonlat ON public.places USING gist (lonlat);


--
-- Name: index_places_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_places_on_user_id ON public.places USING btree (user_id);


--
-- Name: index_points_on_archived_true; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_archived_true ON public.points USING btree (raw_data_archived) WHERE (raw_data_archived = true);


--
-- Name: index_points_on_country_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_country_id ON public.points USING btree (country_id);


--
-- Name: index_points_on_import_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_import_id ON public.points USING btree (import_id);


--
-- Name: index_points_on_lonlat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_lonlat ON public.points USING gist (lonlat);


--
-- Name: index_points_on_lonlat_timestamp_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_points_on_lonlat_timestamp_user_id ON public.points USING btree (lonlat, "timestamp", user_id);


--
-- Name: index_points_on_raw_data_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_raw_data_archive_id ON public.points USING btree (raw_data_archive_id);


--
-- Name: index_points_on_reverse_geocoded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_reverse_geocoded_at ON public.points USING btree (reverse_geocoded_at);


--
-- Name: index_points_on_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_timestamp ON public.points USING btree ("timestamp");


--
-- Name: index_points_on_track_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_track_id ON public.points USING btree (track_id);


--
-- Name: index_points_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_user_id ON public.points USING btree (user_id);


--
-- Name: index_points_on_user_id_and_empty_geodata; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_user_id_and_empty_geodata ON public.points USING btree (user_id, geodata) WHERE (geodata = '{}'::jsonb);


--
-- Name: index_points_on_user_id_and_reverse_geocoded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_user_id_and_reverse_geocoded_at ON public.points USING btree (user_id, reverse_geocoded_at) WHERE (reverse_geocoded_at IS NOT NULL);


--
-- Name: index_points_on_user_id_and_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_user_id_and_timestamp ON public.points USING btree (user_id, "timestamp" DESC);


--
-- Name: index_points_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_on_visit_id ON public.points USING btree (visit_id);


--
-- Name: index_points_raw_data_archives_on_archived_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_raw_data_archives_on_archived_at ON public.points_raw_data_archives USING btree (archived_at);


--
-- Name: index_points_raw_data_archives_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_raw_data_archives_on_user_id ON public.points_raw_data_archives USING btree (user_id);


--
-- Name: index_points_raw_data_archives_on_user_id_and_year_and_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_points_raw_data_archives_on_user_id_and_year_and_month ON public.points_raw_data_archives USING btree (user_id, year, month);


--
-- Name: index_rails_pulse_operations_on_occurred_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_operations_on_occurred_at ON public.rails_pulse_operations USING btree (occurred_at);


--
-- Name: index_rails_pulse_operations_on_operation_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_operations_on_operation_type ON public.rails_pulse_operations USING btree (operation_type);


--
-- Name: index_rails_pulse_operations_on_query_and_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_operations_on_query_and_time ON public.rails_pulse_operations USING btree (query_id, occurred_at);


--
-- Name: index_rails_pulse_operations_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_operations_on_query_id ON public.rails_pulse_operations USING btree (query_id);


--
-- Name: index_rails_pulse_operations_on_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_operations_on_request_id ON public.rails_pulse_operations USING btree (request_id);


--
-- Name: index_rails_pulse_operations_on_time_duration_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_operations_on_time_duration_type ON public.rails_pulse_operations USING btree (occurred_at, duration, operation_type);


--
-- Name: index_rails_pulse_operations_query_performance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_operations_query_performance ON public.rails_pulse_operations USING btree (query_id, duration, occurred_at);


--
-- Name: index_rails_pulse_queries_on_normalized_sql; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_rails_pulse_queries_on_normalized_sql ON public.rails_pulse_queries USING btree (normalized_sql);


--
-- Name: index_rails_pulse_requests_on_occurred_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_requests_on_occurred_at ON public.rails_pulse_requests USING btree (occurred_at);


--
-- Name: index_rails_pulse_requests_on_request_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_rails_pulse_requests_on_request_uuid ON public.rails_pulse_requests USING btree (request_uuid);


--
-- Name: index_rails_pulse_requests_on_route_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_requests_on_route_id ON public.rails_pulse_requests USING btree (route_id);


--
-- Name: index_rails_pulse_requests_on_route_id_and_occurred_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_requests_on_route_id_and_occurred_at ON public.rails_pulse_requests USING btree (route_id, occurred_at);


--
-- Name: index_rails_pulse_routes_on_method_and_path; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_rails_pulse_routes_on_method_and_path ON public.rails_pulse_routes USING btree (method, path);


--
-- Name: index_rails_pulse_summaries_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_summaries_on_created_at ON public.rails_pulse_summaries USING btree (created_at);


--
-- Name: index_rails_pulse_summaries_on_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_summaries_on_period ON public.rails_pulse_summaries USING btree (period_type, period_start);


--
-- Name: index_rails_pulse_summaries_on_summarizable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_rails_pulse_summaries_on_summarizable ON public.rails_pulse_summaries USING btree (summarizable_type, summarizable_id);


--
-- Name: index_stats_on_distance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_distance ON public.stats USING btree (distance);


--
-- Name: index_stats_on_h3_hex_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_h3_hex_ids ON public.stats USING gin (h3_hex_ids) WHERE ((h3_hex_ids IS NOT NULL) AND (h3_hex_ids <> '{}'::jsonb));


--
-- Name: index_stats_on_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_month ON public.stats USING btree (month);


--
-- Name: index_stats_on_sharing_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_stats_on_sharing_uuid ON public.stats USING btree (sharing_uuid);


--
-- Name: index_stats_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_user_id ON public.stats USING btree (user_id);


--
-- Name: index_stats_on_user_id_year_month; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_stats_on_user_id_year_month ON public.stats USING btree (user_id, year, month);


--
-- Name: index_stats_on_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_stats_on_year ON public.stats USING btree (year);


--
-- Name: index_taggings_on_tag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_taggings_on_tag_id ON public.taggings USING btree (tag_id);


--
-- Name: index_taggings_on_taggable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_taggings_on_taggable ON public.taggings USING btree (taggable_type, taggable_id);


--
-- Name: index_taggings_on_taggable_and_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_taggings_on_taggable_and_tag ON public.taggings USING btree (taggable_type, taggable_id, tag_id);


--
-- Name: index_tags_on_privacy_radius_meters; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tags_on_privacy_radius_meters ON public.tags USING btree (privacy_radius_meters) WHERE (privacy_radius_meters IS NOT NULL);


--
-- Name: index_tags_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tags_on_user_id ON public.tags USING btree (user_id);


--
-- Name: index_tags_on_user_id_and_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tags_on_user_id_and_name ON public.tags USING btree (user_id, name);


--
-- Name: index_tracks_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tracks_on_user_id ON public.tracks USING btree (user_id);


--
-- Name: index_trips_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_trips_on_user_id ON public.trips USING btree (user_id);


--
-- Name: index_users_on_api_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_api_key ON public.users USING btree (api_key);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_provider_and_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_provider_and_uid ON public.users USING btree (provider, uid);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_users_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_status ON public.users USING btree (status);


--
-- Name: index_visits_on_area_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_area_id ON public.visits USING btree (area_id);


--
-- Name: index_visits_on_place_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_place_id ON public.visits USING btree (place_id);


--
-- Name: index_visits_on_started_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_started_at ON public.visits USING btree (started_at);


--
-- Name: index_visits_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_user_id ON public.visits USING btree (user_id);


--
-- Name: index_visits_on_user_id_and_status_and_started_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_user_id_and_status_and_started_at ON public.visits USING btree (user_id, status, started_at);


--
-- Name: visits fk_rails_09e5e7c20b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_09e5e7c20b FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rails_pulse_operations fk_rails_0b0064cad4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_operations
    ADD CONSTRAINT fk_rails_0b0064cad4 FOREIGN KEY (query_id) REFERENCES public.rails_pulse_queries(id);


--
-- Name: points fk_rails_206a3ea05e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT fk_rails_206a3ea05e FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: points fk_rails_22278038dd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT fk_rails_22278038dd FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: families fk_rails_3ef59c2ec7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT fk_rails_3ef59c2ec7 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: place_visits fk_rails_5237b3cc14; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits
    ADD CONSTRAINT fk_rails_5237b3cc14 FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- Name: visits fk_rails_5e6ebcb55c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_5e6ebcb55c FOREIGN KEY (area_id) REFERENCES public.areas(id);


--
-- Name: areas fk_rails_64ba63583c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT fk_rails_64ba63583c FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: trips fk_rails_6a33c9e4ea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT fk_rails_6a33c9e4ea FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rails_pulse_operations fk_rails_6eba1e2cb6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_operations
    ADD CONSTRAINT fk_rails_6eba1e2cb6 FOREIGN KEY (request_id) REFERENCES public.rails_pulse_requests(id);


--
-- Name: rails_pulse_requests fk_rails_7fe8602542; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rails_pulse_requests
    ADD CONSTRAINT fk_rails_7fe8602542 FOREIGN KEY (route_id) REFERENCES public.rails_pulse_routes(id);


--
-- Name: family_memberships fk_rails_818aa4a9f9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships
    ADD CONSTRAINT fk_rails_818aa4a9f9 FOREIGN KEY (family_id) REFERENCES public.families(id);


--
-- Name: family_memberships fk_rails_829cfb2ffc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_memberships
    ADD CONSTRAINT fk_rails_829cfb2ffc FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: family_invitations fk_rails_943507cd04; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations
    ADD CONSTRAINT fk_rails_943507cd04 FOREIGN KEY (family_id) REFERENCES public.families(id);


--
-- Name: points fk_rails_98d7bdf4ad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT fk_rails_98d7bdf4ad FOREIGN KEY (raw_data_archive_id) REFERENCES public.points_raw_data_archives(id) ON DELETE SET NULL;


--
-- Name: active_storage_variant_records fk_rails_993965df05; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT fk_rails_993965df05 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: stats fk_rails_9e94901167; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT fk_rails_9e94901167 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: taggings fk_rails_9fcd2e236b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggings
    ADD CONSTRAINT fk_rails_9fcd2e236b FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: tracks fk_rails_a9ae83adcc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT fk_rails_a9ae83adcc FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications fk_rails_b080fb4855; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_b080fb4855 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: active_storage_attachments fk_rails_c3b3935057; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT fk_rails_c3b3935057 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: visits fk_rails_ceb146b88d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_ceb146b88d FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- Name: family_invitations fk_rails_d2f7db596b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.family_invitations
    ADD CONSTRAINT fk_rails_d2f7db596b FOREIGN KEY (invited_by_id) REFERENCES public.users(id);


--
-- Name: points_raw_data_archives fk_rails_dc90211ee5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points_raw_data_archives
    ADD CONSTRAINT fk_rails_dc90211ee5 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tags fk_rails_e689f6d0cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_rails_e689f6d0cc FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: digests fk_rails_ebdc1fb287; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digests
    ADD CONSTRAINT fk_rails_ebdc1fb287 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: place_visits fk_rails_fa8b68cd0c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_visits
    ADD CONSTRAINT fk_rails_fa8b68cd0c FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: points fk_rails_points_raw_data_archives; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT fk_rails_points_raw_data_archives FOREIGN KEY (raw_data_archive_id) REFERENCES public.points_raw_data_archives(id) ON DELETE SET NULL NOT VALID;


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg110+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2026-09-24 12:46:23.852845	2026-09-24 12:46:23.852847
schema_sha1	d1a4e737c9749bfd801fcde971b38e9d4bad9ad2	2026-09-24 12:46:23.857539	2026-09-24 12:46:23.857541
\.


--
-- Data for Name: data_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_migrations (version) FROM stdin;
20240525110530
20240610170930
20240625201842
20240713103122
20240724141417
20240730130922
20240808133112
20240815174852
20240822094532
20241022100309
20241107112451
20241202125248
20241206163450
20250104204852
20250120154554
20250123151849
20250222213848
20250226192005
20250303194123
20250403204658
20250404182629
20250516180933
20250518173936
20250518174305
20250704185707
20250709195003
20250720171241
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
20220325100310
20231021104256
20231021104257
20231021104258
20240315213523
20240315215423
20240317171559
20240323125126
20240323160300
20240323161049
20240323190039
20240324161309
20240324161800
20240324173315
20240404154959
20240425200155
20240518095848
20240525110244
20240612152451
20240620205120
20240630093005
20240703105734
20240712141303
20240713103051
20240721165313
20240721183005
20240721183116
20240805150111
20240808102348
20240808102425
20240808121027
20240822092405
20241127161621
20241128095325
20241202114820
20241205160055
20241211113119
20241226202204
20241226202831
20250120152014
20250120152540
20250120154555
20250123145155
20250123151657
20250219195822
20250221181805
20250221185032
20250221194430
20250221194509
20250303194009
20250303194043
20250324180755
20250404182437
20250513164521
20250515190752
20250515192211
20250625185030
20250627184017
20250703193656
20250703193657
20250721204404
20250723164055
20250728191359
20250821192219
20250823125940
20250905120121
20250910224538
20250910224714
20250918215512
20250926220114
20250926220135
20250926220158
20250926220345
20251028130433
20251030190924
20251116184506
20251116184514
20251116184520
20251118204141
20251118210506
20251201192510
20251206000001
20251206000002
20251206000004
20251208210410
20251210193532
20251226170919
20251227000001
20251227223614
20251228000000
20251228100000
20251228163703
20260103114630
20260112192240
20260113230537
\.


--
-- PostgreSQL database dump complete
--

